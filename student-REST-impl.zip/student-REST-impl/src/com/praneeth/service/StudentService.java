package com.praneeth.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.praneeth.database.DataBaseDAO;
import com.praneeth.model.Student;

public class StudentService {
	private Map<Long, Student> student = DataBaseDAO.getStudents();

	public StudentService() {
		student.put(1l, new Student(1l, "praneeth", "osmania college", 8498995302l));
		student.put(2l, new Student(2l, "naresh", "osmania college", 9398310843l));
		student.put(3l, new Student(3l, "vinod", "palamuru college", 94441444148l));
	}

	public List<Student> getAllStudents() {
		return new ArrayList<Student>(student.values());
	}

	public Student getStudents(long sid) {
		return student.get(sid);
	}

	public Student addStudent(Student s) {
		s.setSid((long) (student.size() + 1));
		student.put(s.getSid(), s);
		return s;
	}

	public Student removeStudent(long id) {
		return student.remove(id);
	}

	public Student updateStudent(Student s) {
		if (s.getSid() == 0) {
			return null;
		}
		student.put(s.getSid(), s);
		return s;
	}
}
