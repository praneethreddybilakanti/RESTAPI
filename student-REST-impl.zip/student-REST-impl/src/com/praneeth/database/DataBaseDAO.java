package com.praneeth.database;

import java.util.HashMap;
import java.util.Map;

import com.praneeth.model.Student;

public class DataBaseDAO  {

	private static Map<Long,Student> student=new HashMap<>();
	public static Map<Long,Student> getStudents()
	{
		return student;
	}
	
	
	
}
