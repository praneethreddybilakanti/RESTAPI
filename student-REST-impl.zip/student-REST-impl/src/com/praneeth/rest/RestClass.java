package com.praneeth.rest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.praneeth.model.Student;
import com.praneeth.service.StudentService;

@Path("/rest")
public class RestClass {
	private StudentService studentservice = new StudentService();

	public RestClass() {
		// TODO Auto-generated constructor stub
		System.out.println("rest class concstructor");
	}

	@GET
	@Path("/students")
	@Produces(MediaType.APPLICATION_XML)
	public List<Student> getAllStudents() {

		return studentservice.getAllStudents();
	}
	@	POST
	@Path("/add")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
	public Student addStudents(Student s)
	{
		studentservice.addStudent(s);
		return  s;
	}
	@GET
	@Path("/retrive/{sid}")
@Produces(MediaType.APPLICATION_XML)
	public Student getstudentId(@PathParam("sid") long id)
	{
		
		return studentservice.getStudents(id);
	}
	@PUT
	@Path("/update")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
	public Student updateStudent(Student st)
	{
		System.out.println("update");
		return studentservice.updateStudent(st);
	}
	@DELETE
	@Path("/delete/{id}")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
public Student removeStudent(@PathParam("id") Long id)
{
		return studentservice.removeStudent(id);
}
}
