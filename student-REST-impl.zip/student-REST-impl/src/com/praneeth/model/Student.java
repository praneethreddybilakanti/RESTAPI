package com.praneeth.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Student {
	
private Long sid;
private String name;
private String clgname;
private long phno;
public Student() {
	// TODO Auto-generated constructor stub
}
public Student(Long sid, String name, String clgname, long phno) {
	super();
	this.sid = sid;
	this.name = name;
	this.clgname = clgname;
	this.phno = phno;
}
public Long getSid() {
	return sid;
}
public void setSid(Long sid) {
	this.sid = sid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getClgname() {
	return clgname;
}
public void setClgname(String clgname) {
	this.clgname = clgname;
}
public long getPhno() {
	return phno;
}
public void setPhno(long phno) {
	this.phno = phno;
}
}
